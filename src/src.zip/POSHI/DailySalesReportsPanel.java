package POSHI;

import javax.swing.JPanel;

public class DailySalesReportsPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public DailySalesReportsPanel() {

	}

}
